/********************************************************************************
** Form generated from reading UI file 'nvocdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NVOCDIALOG_H
#define UI_NVOCDIALOG_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSlider>

QT_BEGIN_NAMESPACE

class Ui_nvOCDialog
{
public:
    QLabel *label_2;
    QSlider *horizontalSliderFanSpeed;
    QComboBox *comboBoxDevice;
    QLabel *label;
    QLabel *label_5;
    QLabel *label_3;
    QLabel *label_4;
    QSlider *horizontalSliderGpuOffset;
    QSlider *horizontalSliderMemOffset;
    QLCDNumber *lcdNumberMemClock;
    QLCDNumber *lcdNumberGpuOffset;
    QLCDNumber *lcdNumberPowerPercent;
    QSlider *horizontalSliderPowerPercent;
    QCheckBox *checkBoxAutoSpeedFan;
    QCheckBox *checkBoxAllDevices;
    QCheckBox *checkBoxOCMinerStart;
    QDialogButtonBox *buttonBox;
    QLCDNumber *lcdNumberFanSpeed;

    void setupUi(QDialog *nvOCDialog)
    {
        if (nvOCDialog->objectName().isEmpty())
            nvOCDialog->setObjectName(QString::fromUtf8("nvOCDialog"));
        nvOCDialog->resize(666, 264);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(nvOCDialog->sizePolicy().hasHeightForWidth());
        nvOCDialog->setSizePolicy(sizePolicy);
        nvOCDialog->setStyleSheet(QString::fromUtf8("QWidget{\n"
"background-color: #11192C;\n"
"}"));
        label_2 = new QLabel(nvOCDialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(11, 103, 108, 16));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);
        horizontalSliderFanSpeed = new QSlider(nvOCDialog);
        horizontalSliderFanSpeed->setObjectName(QString::fromUtf8("horizontalSliderFanSpeed"));
        horizontalSliderFanSpeed->setGeometry(QRect(136, 190, 431, 22));
        horizontalSliderFanSpeed->setStyleSheet(QString::fromUtf8("QSlider::groove:horizontal {\n"
"    height: 8px; \n"
"    background: #CFD0D2;\n"
"    border-radius: 4px;\n"
"    padding: 0px;\n"
"    margin: 0px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: #F8CD26;\n"
"    width: 17px;\n"
"    margin: -5px 0;\n"
"    height:17px;\n"
"    border-radius: 8px;\n"
"    border-width: 0px;\n"
"}\n"
"\n"
"QSlider::sub-page:horizontal{\n"
"    background: #366CB8;\n"
"    border-radius: 4px;\n"
"    height: 8px;\n"
"}\n"
"\n"
""));
        horizontalSliderFanSpeed->setMaximum(100);
        horizontalSliderFanSpeed->setOrientation(Qt::Horizontal);
        comboBoxDevice = new QComboBox(nvOCDialog);
        comboBoxDevice->setObjectName(QString::fromUtf8("comboBoxDevice"));
        comboBoxDevice->setGeometry(QRect(140, 20, 161, 22));
        comboBoxDevice->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    border-radius: 3px;\n"
"    padding: 1px 18px 1px 3px;\n"
"    border-width: 0px;\n"
"}\n"
"\n"
"QComboBox:editable {\n"
"    background:  #3D8ED6;\n"
"}\n"
"\n"
"QComboBox:!editable, QComboBox::drop-down:editable {\n"
"     background: #3D8ED6;\n"
"}\n"
"\n"
"QComboBox:!editable:on, QComboBox::drop-down:editable:on {\n"
"    background: #3D8ED6;\n"
"}\n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 15px;\n"
"    border-left-width: 1px;\n"
"    border-left-color: #366CB8;\n"
"    border-left-style: solid; \n"
"    border-top-right-radius: 3px; /* same radius as the QComboBox */\n"
"    border-bottom-right-radius: 3px;\n"
"}\n"
"\n"
"QComboBox::down-arrow {\n"
"    border-image: url(:/images/arrow_down.png) ;\n"
"}\n"
"\n"
"QComboBox::down-arrow:on { /* shift the arrow when popup is open */\n"
"    top: 1px;\n"
"   \n"
"}\n"
""));
        label = new QLabel(nvOCDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(11, 62, 102, 16));
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label_5 = new QLabel(nvOCDialog);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(11, 22, 52, 16));
        sizePolicy1.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy1);
        label_3 = new QLabel(nvOCDialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(11, 144, 109, 16));
        sizePolicy1.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy1);
        label_4 = new QLabel(nvOCDialog);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(11, 190, 101, 16));
        sizePolicy1.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy1);
        horizontalSliderGpuOffset = new QSlider(nvOCDialog);
        horizontalSliderGpuOffset->setObjectName(QString::fromUtf8("horizontalSliderGpuOffset"));
        horizontalSliderGpuOffset->setGeometry(QRect(136, 103, 431, 22));
        horizontalSliderGpuOffset->setStyleSheet(QString::fromUtf8("QSlider::groove:horizontal {\n"
"    height: 8px; \n"
"    background: #CFD0D2;\n"
"    border-radius: 4px;\n"
"    padding: 0px;\n"
"    margin: 0px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: #F8CD26;\n"
"    width: 17px;\n"
"    margin: -5px 0;\n"
"    height:17px;\n"
"    border-radius: 8px;\n"
"    border-width: 0px;\n"
"}\n"
"\n"
"QSlider::sub-page:horizontal{\n"
"    background: #366CB8;\n"
"    border-radius: 4px;\n"
"    height: 8px;\n"
"}\n"
"\n"
""));
        horizontalSliderGpuOffset->setMinimum(-200);
        horizontalSliderGpuOffset->setMaximum(200);
        horizontalSliderGpuOffset->setOrientation(Qt::Horizontal);
        horizontalSliderMemOffset = new QSlider(nvOCDialog);
        horizontalSliderMemOffset->setObjectName(QString::fromUtf8("horizontalSliderMemOffset"));
        horizontalSliderMemOffset->setGeometry(QRect(136, 144, 431, 22));
        horizontalSliderMemOffset->setStyleSheet(QString::fromUtf8("QSlider::groove:horizontal {\n"
"    height: 8px; \n"
"    background: #CFD0D2;\n"
"    border-radius: 4px;\n"
"    padding: 0px;\n"
"    margin: 0px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: #F8CD26;\n"
"    width: 17px;\n"
"    margin: -5px 0;\n"
"    height:17px;\n"
"    border-radius: 8px;\n"
"    border-width: 0px;\n"
"}\n"
"\n"
"QSlider::sub-page:horizontal{\n"
"    background: #366CB8;\n"
"    border-radius: 4px;\n"
"    height: 8px;\n"
"}\n"
"\n"
""));
        horizontalSliderMemOffset->setMinimum(-1500);
        horizontalSliderMemOffset->setMaximum(1500);
        horizontalSliderMemOffset->setOrientation(Qt::Horizontal);
        lcdNumberMemClock = new QLCDNumber(nvOCDialog);
        lcdNumberMemClock->setObjectName(QString::fromUtf8("lcdNumberMemClock"));
        lcdNumberMemClock->setGeometry(QRect(590, 144, 64, 23));
        lcdNumberMemClock->setStyleSheet(QString::fromUtf8("QLCDNumber{\n"
"	background-color: transparent;\n"
"    color: #366CB8;\n"
"}"));
        lcdNumberMemClock->setSegmentStyle(QLCDNumber::Flat);
        lcdNumberGpuOffset = new QLCDNumber(nvOCDialog);
        lcdNumberGpuOffset->setObjectName(QString::fromUtf8("lcdNumberGpuOffset"));
        lcdNumberGpuOffset->setGeometry(QRect(590, 103, 64, 23));
        lcdNumberGpuOffset->setStyleSheet(QString::fromUtf8("QLCDNumber{\n"
"	background-color: transparent;\n"
"    color: #366CB8;\n"
"}"));
        lcdNumberGpuOffset->setSegmentStyle(QLCDNumber::Flat);
        lcdNumberPowerPercent = new QLCDNumber(nvOCDialog);
        lcdNumberPowerPercent->setObjectName(QString::fromUtf8("lcdNumberPowerPercent"));
        lcdNumberPowerPercent->setGeometry(QRect(590, 62, 64, 23));
        lcdNumberPowerPercent->setStyleSheet(QString::fromUtf8("QLCDNumber{\n"
"	background-color: transparent;\n"
"    color: #366CB8;\n"
"}"));
        lcdNumberPowerPercent->setDigitCount(5);
        lcdNumberPowerPercent->setSegmentStyle(QLCDNumber::Flat);
        horizontalSliderPowerPercent = new QSlider(nvOCDialog);
        horizontalSliderPowerPercent->setObjectName(QString::fromUtf8("horizontalSliderPowerPercent"));
        horizontalSliderPowerPercent->setGeometry(QRect(136, 62, 431, 22));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(horizontalSliderPowerPercent->sizePolicy().hasHeightForWidth());
        horizontalSliderPowerPercent->setSizePolicy(sizePolicy2);
        horizontalSliderPowerPercent->setStyleSheet(QString::fromUtf8("QSlider::groove:horizontal {\n"
"    height: 8px; \n"
"    background: #CFD0D2;\n"
"    border-radius: 4px;\n"
"    padding: 0px;\n"
"    margin: 0px;\n"
"}\n"
"\n"
"QSlider::handle:horizontal {\n"
"    background: #F8CD26;\n"
"    width: 17px;\n"
"    margin: -5px 0;\n"
"    height:17px;\n"
"    border-radius: 8px;\n"
"    border-width: 0px;\n"
"}\n"
"\n"
"QSlider::sub-page:horizontal{\n"
"    background: #366CB8;\n"
"    border-radius: 4px;\n"
"    height: 8px;\n"
"}\n"
"\n"
""));
        horizontalSliderPowerPercent->setMinimum(50);
        horizontalSliderPowerPercent->setMaximum(100);
        horizontalSliderPowerPercent->setOrientation(Qt::Horizontal);
        checkBoxAutoSpeedFan = new QCheckBox(nvOCDialog);
        checkBoxAutoSpeedFan->setObjectName(QString::fromUtf8("checkBoxAutoSpeedFan"));
        checkBoxAutoSpeedFan->setEnabled(true);
        checkBoxAutoSpeedFan->setGeometry(QRect(130, 220, 121, 20));
        checkBoxAutoSpeedFan->setStyleSheet(QString::fromUtf8("QCheckBox {\n"
"    width: 13px;\n"
"    height: 13px;\n"
"}\n"
"QCheckBox::indicator:unchecked {\n"
"    border: 2px solid #366CB8;\n"
"   border-radius: 2px;\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"   background: #F9CD28;\n"
"   border: 2px solid #366CB8;\n"
"   border-radius: 2px;\n"
"}"));
        checkBoxAutoSpeedFan->setTristate(false);
        checkBoxAllDevices = new QCheckBox(nvOCDialog);
        checkBoxAllDevices->setObjectName(QString::fromUtf8("checkBoxAllDevices"));
        checkBoxAllDevices->setGeometry(QRect(320, 20, 385, 20));
        checkBoxAllDevices->setStyleSheet(QString::fromUtf8("QCheckBox {\n"
"    width: 13px;\n"
"    height: 13px;\n"
"}\n"
"QCheckBox::indicator:unchecked {\n"
"    border: 2px solid #366CB8;\n"
"   border-radius: 2px;\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"   background: #F9CD28;\n"
"   border: 2px solid #366CB8;\n"
"   border-radius: 2px;\n"
"}"));
        checkBoxOCMinerStart = new QCheckBox(nvOCDialog);
        checkBoxOCMinerStart->setObjectName(QString::fromUtf8("checkBoxOCMinerStart"));
        checkBoxOCMinerStart->setGeometry(QRect(480, 20, 214, 20));
        checkBoxOCMinerStart->setStyleSheet(QString::fromUtf8("QCheckBox {\n"
"    width: 13px;\n"
"    height: 13px;\n"
"}\n"
"QCheckBox::indicator:unchecked {\n"
"    border: 2px solid #366CB8;\n"
"   border-radius: 2px;\n"
"}\n"
"\n"
"QCheckBox::indicator:checked {\n"
"   background: #F9CD28;\n"
"   border: 2px solid #366CB8;\n"
"   border-radius: 2px;\n"
"}"));
        buttonBox = new QDialogButtonBox(nvOCDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(190, 220, 461, 31));
        buttonBox->setLayoutDirection(Qt::LeftToRight);
        buttonBox->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 15px;\n"
"	font: 75 10pt \"MS Shell Dlg 2\";\n"
"    background-color: #71C8F3;\n"
"	min-width:  100px;\n"
"	min-height:  30px;\n"
"    max-width:  100px;\n"
"	max-height:  30px;\n"
"    padding:  0;\n"
"    margin: 0;\n"
"}\n"
"QPushButton:hover{\n"
"    background-color: #3D8ED6;\n"
"}\n"
"QPushButton:hover:pressed{\n"
"    background-color: #2F5BAC;\n"
"}\n"
""));
        buttonBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Apply|QDialogButtonBox::Close);
        lcdNumberFanSpeed = new QLCDNumber(nvOCDialog);
        lcdNumberFanSpeed->setObjectName(QString::fromUtf8("lcdNumberFanSpeed"));
        lcdNumberFanSpeed->setGeometry(QRect(590, 190, 64, 23));
        lcdNumberFanSpeed->setStyleSheet(QString::fromUtf8("QLCDNumber{\n"
"	background-color: transparent;\n"
"    color: #366CB8;\n"
"}"));
        lcdNumberFanSpeed->setSegmentStyle(QLCDNumber::Flat);

        retranslateUi(nvOCDialog);
        QObject::connect(buttonBox, SIGNAL(accepted()), nvOCDialog, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), nvOCDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(nvOCDialog);
    } // setupUi

    void retranslateUi(QDialog *nvOCDialog)
    {
        nvOCDialog->setWindowTitle(QApplication::translate("nvOCDialog", "Overclocking", nullptr));
        label_2->setText(QApplication::translate("nvOCDialog", "Core Clock (MHz) :", nullptr));
        label->setText(QApplication::translate("nvOCDialog", "Power Limit (%) :", nullptr));
        label_5->setText(QApplication::translate("nvOCDialog", "Devices :", nullptr));
        label_3->setText(QApplication::translate("nvOCDialog", "Mem Clock (MHz) :", nullptr));
        label_4->setText(QApplication::translate("nvOCDialog", "Fan Speed (%) :", nullptr));
        checkBoxAutoSpeedFan->setText(QApplication::translate("nvOCDialog", "Auto", nullptr));
        checkBoxAllDevices->setText(QApplication::translate("nvOCDialog", "Apply to all devices", nullptr));
        checkBoxOCMinerStart->setText(QApplication::translate("nvOCDialog", "Apply on each miner restart", nullptr));
    } // retranslateUi

};

namespace Ui {
    class nvOCDialog: public Ui_nvOCDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NVOCDIALOG_H

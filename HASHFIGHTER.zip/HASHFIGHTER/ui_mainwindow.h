/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "circularprogress.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QFormLayout *formLayout_2;
    QVBoxLayout *verticalLayout_2;
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QFormLayout *formLayout;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QLabel *label_34;
    QComboBox *useSSL;
    QLabel *label_36;
    QLineEdit *wallet;
    QLabel *label_37;
    QLineEdit *worker;
    QLabel *label_35;
    QLineEdit *poolPort;
    QLabel *label_38;
    QLineEdit *email;
    QLineEdit *lineEditArgs;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_4;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_15;
    CircularProgress *lcdNumberMinWatt;
    QGroupBox *groupBox_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_14;
    CircularProgress *lcdNumberMaxWatt;
    QGroupBox *groupBox_4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_6;
    CircularProgress *lcdNumberMaxGPUTemp;
    QGroupBox *groupBox_8;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_13;
    CircularProgress *lcdNumberMinGPUTemp;
    QGroupBox *groupBox_9;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_9;
    CircularProgress *lcdNumberMaxFanSpeed;
    QGroupBox *groupBox_10;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_11;
    CircularProgress *lcdNumberMinFanSpeed;
    QGroupBox *groupBox_11;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_16;
    CircularProgress *lcdNumberMaxGPUClock;
    QGroupBox *groupBox_12;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_17;
    CircularProgress *lcdNumberMinGPUClock;
    QGroupBox *groupBox_13;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_10;
    CircularProgress *lcdNumberMaxMemClock;
    QGroupBox *groupBox_14;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_12;
    CircularProgress *lcdNumberMinMemClock;
    QWidget *tab_2;
    QGridLayout *gridLayout_3;
    QGroupBox *groupBox_18;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_25;
    CircularProgress *lcdNumber_AMD_MinTemp;
    QGroupBox *groupBox_17;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_24;
    CircularProgress *lcdNumber_AMD_MaxTemp;
    QGroupBox *groupBox_16;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_33;
    CircularProgress *lcdNumber_AMD_MinPoxer;
    QGroupBox *groupBox_15;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_32;
    CircularProgress *lcdNumber_AMD_MaxPower;
    QGroupBox *groupBox_33;
    QHBoxLayout *horizontalLayout_35;
    QLabel *label_27;
    CircularProgress *lcdNumber_AMD_MaxFan;
    QGroupBox *groupBox_34;
    QHBoxLayout *horizontalLayout_36;
    QLabel *label_26;
    CircularProgress *lcdNumber_AMD_MinFan;
    QGroupBox *groupBox_35;
    QHBoxLayout *horizontalLayout_37;
    QLabel *label_28;
    CircularProgress *lcdNumber_AMD_MaxClock;
    QGroupBox *groupBox_36;
    QHBoxLayout *horizontalLayout_38;
    QLabel *label_29;
    CircularProgress *lcdNumber_AMD_MinClock;
    QGroupBox *groupBox_37;
    QHBoxLayout *horizontalLayout_39;
    QLabel *label_30;
    CircularProgress *lcdNumber_AMD_MaxMemClock;
    QGroupBox *groupBox_38;
    QHBoxLayout *horizontalLayout_40;
    QLabel *label_31;
    CircularProgress *lcdNumber_AMD_MinMemClock;
    QWidget *tab_3;
    QHBoxLayout *horizontalLayout;
    QGroupBox *groupBoxWatchdog;
    QGridLayout *gridLayout;
    QSpinBox *spinBoxMax0MHs;
    QLabel *label_3;
    QSpinBox *spinBoxDelay0MHs;
    QSpinBox *spinBoxDelay;
    QLabel *label_4;
    QLabel *label_7;
    QLabel *label_5;
    QSpinBox *spinBoxDelayNoHash;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1223, 461);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(2);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("Tahoma"));
        font.setPointSize(10);
        MainWindow->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8("gui_miner.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setStyleSheet(QString::fromUtf8("QSpinBox {\n"
"margin-top: 20px;  /* make room for the arrows */\n"
"margin-bottom: 20px;  /* make room for the arrows */\n"
"width: 40px;\n"
"height: 20px;\n"
"min-height: 20px;\n"
"max-width: 60px;\n"
"background-color: #353535;\n"
"border: 0px;\n"
"color: #ffffff;\n"
"qproperty-alignment: AlignCenter;\n"
"}\n"
"\n"
"QSpinBox::up-button  {\n"
"subcontrol-origin: margin;\n"
"subcontrol-position: center top;\n"
"height: 20px;\n"
"width: 40px;\n"
"border-width: 2px;\n"
"background-color: #353535;\n"
" border-top-left-radius: 20px;\n"
" border-top-right-radius: 20px;\n"
"}\n"
"\n"
"QSpinBox::up-arrow  {\n"
"image: url(:/images/up.png);\n"
"\n"
"min-width: 20px;\n"
"min-height: 20px;\n"
"max-width: 20px;\n"
"max-height: 20px;\n"
"height: 20px;\n"
"width: 20px;\n"
"}\n"
"\n"
"QSpinBox::up-button:pressed  {\n"
"top: 1px;\n"
"right: 1px;\n"
"}\n"
"\n"
"QSpinBox::down-button  {\n"
"subcontrol-origin: margin;\n"
"subcontrol-position: center bottom;\n"
"height: 20px;\n"
"width: 40px;\n"
"border-width: 2px;\n"
"backgrou"
                        "nd-color: #353535;\n"
" border-bottom-left-radius: 20px;\n"
" border-bottom-right-radius: 20px;\n"
"}\n"
"\n"
"QSpinBox::down-arrow  {\n"
"image: url(:/images/down.png);\n"
"\n"
"min-width: 20px;\n"
"min-height: 20px;\n"
"max-width: 20px;\n"
"max-height: 20px;\n"
"height: 20px;\n"
"width: 20px;\n"
"}\n"
"\n"
"QSpinBox::down-button:pressed  {\n"
"top: 1px;\n"
"left: 1px;\n"
"}\n"
"\n"
"CircularProgress{\n"
"	margin: 0px;\n"
"	padding: 0px;\n"
"}\n"
"\n"
""));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        formLayout_2 = new QFormLayout(centralWidget);
        formLayout_2->setSpacing(6);
        formLayout_2->setContentsMargins(11, 11, 11, 11);
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setMinimumSize(QSize(400, 0));
        textEdit->setStyleSheet(QString::fromUtf8(""));
        textEdit->setReadOnly(true);

        verticalLayout_2->addWidget(textEdit);

        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy1);
        pushButton->setMinimumSize(QSize(202, 72));
        pushButton->setMaximumSize(QSize(1202, 72));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        pushButton->setFont(font1);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"	min-width:  200px;\n"
"	min-height:  70px;\n"
"    max-width:  1200px;\n"
"	max-height:  70px;\n"
"}\n"
"\n"
""));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/button.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon1);
        pushButton->setIconSize(QSize(65, 65));

        verticalLayout_2->addWidget(pushButton);


        formLayout_2->setLayout(0, QFormLayout::LabelRole, verticalLayout_2);

        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setSizeConstraint(QLayout::SetMinimumSize);
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setAlignment(Qt::AlignCenter);
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_34 = new QLabel(groupBox);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Consolas"));
        font2.setBold(true);
        font2.setItalic(false);
        font2.setUnderline(false);
        font2.setWeight(75);
        font2.setStyleStrategy(QFont::PreferAntialias);
        label_34->setFont(font2);
        label_34->setLayoutDirection(Qt::LeftToRight);
        label_34->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(label_34);

        useSSL = new QComboBox(groupBox);
        useSSL->addItem(QString());
        useSSL->addItem(QString());
        useSSL->setObjectName(QString::fromUtf8("useSSL"));

        verticalLayout->addWidget(useSSL);

        label_36 = new QLabel(groupBox);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setFont(font2);
        label_36->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(label_36);

        wallet = new QLineEdit(groupBox);
        wallet->setObjectName(QString::fromUtf8("wallet"));

        verticalLayout->addWidget(wallet);

        label_37 = new QLabel(groupBox);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setFont(font2);
        label_37->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(label_37);

        worker = new QLineEdit(groupBox);
        worker->setObjectName(QString::fromUtf8("worker"));

        verticalLayout->addWidget(worker);

        label_35 = new QLabel(groupBox);
        label_35->setObjectName(QString::fromUtf8("label_35"));
        label_35->setFont(font2);
        label_35->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(label_35);

        poolPort = new QLineEdit(groupBox);
        poolPort->setObjectName(QString::fromUtf8("poolPort"));

        verticalLayout->addWidget(poolPort);

        label_38 = new QLabel(groupBox);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setFont(font2);
        label_38->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout->addWidget(label_38);

        email = new QLineEdit(groupBox);
        email->setObjectName(QString::fromUtf8("email"));

        verticalLayout->addWidget(email);


        formLayout->setWidget(0, QFormLayout::SpanningRole, groupBox);

        lineEditArgs = new QLineEdit(centralWidget);
        lineEditArgs->setObjectName(QString::fromUtf8("lineEditArgs"));

        formLayout->setWidget(1, QFormLayout::SpanningRole, lineEditArgs);

        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setMinimumSize(QSize(0, 100));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        tab->setStyleSheet(QString::fromUtf8("QGroupBox{\n"
"	background-color: #262728;\n"
"	border-radius: 4px;\n"
"	border-color: #262728;\n"
"	color: #ffffff;\n"
" 	margin : 0px;\n"
"	padding: 0 0 0 0;\n"
" 	margin-top: 0px;\n"
"	margin-bottom: 0px;\n"
"	min-height: 58px;\n"
"\n"
"}\n"
"\n"
"QLabel{\n"
"color: #ffffff;\n"
"}\n"
"\n"
""));
        gridLayout_4 = new QGridLayout(tab);
        gridLayout_4->setSpacing(6);
        gridLayout_4->setContentsMargins(11, 11, 11, 11);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        groupBox_3 = new QGroupBox(tab);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        horizontalLayout_3 = new QHBoxLayout(groupBox_3);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(-1, 0, -1, 0);
        label_15 = new QLabel(groupBox_3);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        horizontalLayout_3->addWidget(label_15);

        lcdNumberMinWatt = new CircularProgress(groupBox_3);
        lcdNumberMinWatt->setObjectName(QString::fromUtf8("lcdNumberMinWatt"));
        lcdNumberMinWatt->setMinimumSize(QSize(50, 50));
        lcdNumberMinWatt->setMaximumSize(QSize(50, 50));
        lcdNumberMinWatt->setMax(100);
        lcdNumberMinWatt->setValue(0);
        lcdNumberMinWatt->setBgColor(QColor(255, 255, 255));
        lcdNumberMinWatt->setValueColor(QColor(48, 224, 77));
        lcdNumberMinWatt->setBarWidth(10);
        lcdNumberMinWatt->setProperty("showtext", QVariant(true));
        lcdNumberMinWatt->setProperty("infinity", QVariant(false));

        horizontalLayout_3->addWidget(lcdNumberMinWatt);


        gridLayout_4->addWidget(groupBox_3, 1, 0, 1, 1);

        groupBox_2 = new QGroupBox(tab);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setMinimumSize(QSize(0, 58));
        groupBox_2->setStyleSheet(QString::fromUtf8(""));
        groupBox_2->setFlat(false);
        horizontalLayout_2 = new QHBoxLayout(groupBox_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(-1, 0, -1, 0);
        label_14 = new QLabel(groupBox_2);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        horizontalLayout_2->addWidget(label_14);

        lcdNumberMaxWatt = new CircularProgress(groupBox_2);
        lcdNumberMaxWatt->setObjectName(QString::fromUtf8("lcdNumberMaxWatt"));
        lcdNumberMaxWatt->setMinimumSize(QSize(50, 50));
        lcdNumberMaxWatt->setMaximumSize(QSize(50, 50));
        lcdNumberMaxWatt->setStyleSheet(QString::fromUtf8("CircularProgress{\n"
"	qproperty-bgColor: #ffffff;\n"
"}"));
        lcdNumberMaxWatt->setMax(100);
        lcdNumberMaxWatt->setValue(0);
        lcdNumberMaxWatt->setValueColor(QColor(48, 224, 77));
        lcdNumberMaxWatt->setBarWidth(10);
        lcdNumberMaxWatt->setProperty("showtext", QVariant(true));
        lcdNumberMaxWatt->setProperty("infinity", QVariant(false));

        horizontalLayout_2->addWidget(lcdNumberMaxWatt);


        gridLayout_4->addWidget(groupBox_2, 0, 0, 1, 1);

        groupBox_4 = new QGroupBox(tab);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setMinimumSize(QSize(0, 58));
        groupBox_4->setStyleSheet(QString::fromUtf8(""));
        groupBox_4->setFlat(false);
        horizontalLayout_4 = new QHBoxLayout(groupBox_4);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(-1, 0, -1, 0);
        label_6 = new QLabel(groupBox_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_4->addWidget(label_6);

        lcdNumberMaxGPUTemp = new CircularProgress(groupBox_4);
        lcdNumberMaxGPUTemp->setObjectName(QString::fromUtf8("lcdNumberMaxGPUTemp"));
        lcdNumberMaxGPUTemp->setMinimumSize(QSize(50, 50));
        lcdNumberMaxGPUTemp->setMaximumSize(QSize(50, 50));
        lcdNumberMaxGPUTemp->setMax(100);
        lcdNumberMaxGPUTemp->setValue(0);
        lcdNumberMaxGPUTemp->setBgColor(QColor(255, 255, 255));
        lcdNumberMaxGPUTemp->setValueColor(QColor(48, 224, 77));
        lcdNumberMaxGPUTemp->setBarWidth(10);
        lcdNumberMaxGPUTemp->setProperty("showtext", QVariant(true));
        lcdNumberMaxGPUTemp->setProperty("infinity", QVariant(false));

        horizontalLayout_4->addWidget(lcdNumberMaxGPUTemp);


        gridLayout_4->addWidget(groupBox_4, 0, 1, 1, 1);

        groupBox_8 = new QGroupBox(tab);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setMinimumSize(QSize(0, 58));
        groupBox_8->setStyleSheet(QString::fromUtf8(""));
        groupBox_8->setFlat(false);
        horizontalLayout_9 = new QHBoxLayout(groupBox_8);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(-1, 0, -1, 0);
        label_13 = new QLabel(groupBox_8);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        horizontalLayout_9->addWidget(label_13);

        lcdNumberMinGPUTemp = new CircularProgress(groupBox_8);
        lcdNumberMinGPUTemp->setObjectName(QString::fromUtf8("lcdNumberMinGPUTemp"));
        lcdNumberMinGPUTemp->setMinimumSize(QSize(50, 50));
        lcdNumberMinGPUTemp->setMaximumSize(QSize(50, 50));
        lcdNumberMinGPUTemp->setMax(100);
        lcdNumberMinGPUTemp->setValue(0);
        lcdNumberMinGPUTemp->setBgColor(QColor(255, 255, 255));
        lcdNumberMinGPUTemp->setValueColor(QColor(48, 224, 77));
        lcdNumberMinGPUTemp->setBarWidth(10);
        lcdNumberMinGPUTemp->setProperty("showtext", QVariant(true));
        lcdNumberMinGPUTemp->setProperty("infinity", QVariant(false));

        horizontalLayout_9->addWidget(lcdNumberMinGPUTemp);


        gridLayout_4->addWidget(groupBox_8, 1, 1, 1, 1);

        groupBox_9 = new QGroupBox(tab);
        groupBox_9->setObjectName(QString::fromUtf8("groupBox_9"));
        groupBox_9->setMinimumSize(QSize(0, 58));
        groupBox_9->setStyleSheet(QString::fromUtf8(""));
        groupBox_9->setFlat(false);
        horizontalLayout_10 = new QHBoxLayout(groupBox_9);
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        horizontalLayout_10->setContentsMargins(-1, 0, -1, 0);
        label_9 = new QLabel(groupBox_9);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_10->addWidget(label_9);

        lcdNumberMaxFanSpeed = new CircularProgress(groupBox_9);
        lcdNumberMaxFanSpeed->setObjectName(QString::fromUtf8("lcdNumberMaxFanSpeed"));
        lcdNumberMaxFanSpeed->setMinimumSize(QSize(50, 50));
        lcdNumberMaxFanSpeed->setMaximumSize(QSize(50, 50));
        lcdNumberMaxFanSpeed->setMax(100);
        lcdNumberMaxFanSpeed->setValue(0);
        lcdNumberMaxFanSpeed->setBgColor(QColor(255, 255, 255));
        lcdNumberMaxFanSpeed->setValueColor(QColor(48, 224, 77));
        lcdNumberMaxFanSpeed->setBarWidth(10);
        lcdNumberMaxFanSpeed->setProperty("showtext", QVariant(true));
        lcdNumberMaxFanSpeed->setProperty("infinity", QVariant(false));

        horizontalLayout_10->addWidget(lcdNumberMaxFanSpeed);


        gridLayout_4->addWidget(groupBox_9, 0, 2, 1, 1);

        groupBox_10 = new QGroupBox(tab);
        groupBox_10->setObjectName(QString::fromUtf8("groupBox_10"));
        groupBox_10->setMinimumSize(QSize(0, 58));
        groupBox_10->setStyleSheet(QString::fromUtf8(""));
        groupBox_10->setFlat(false);
        horizontalLayout_11 = new QHBoxLayout(groupBox_10);
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(-1, 0, -1, 0);
        label_11 = new QLabel(groupBox_10);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        horizontalLayout_11->addWidget(label_11);

        lcdNumberMinFanSpeed = new CircularProgress(groupBox_10);
        lcdNumberMinFanSpeed->setObjectName(QString::fromUtf8("lcdNumberMinFanSpeed"));
        lcdNumberMinFanSpeed->setMinimumSize(QSize(50, 50));
        lcdNumberMinFanSpeed->setMaximumSize(QSize(50, 50));
        lcdNumberMinFanSpeed->setMax(100);
        lcdNumberMinFanSpeed->setValue(0);
        lcdNumberMinFanSpeed->setBgColor(QColor(255, 255, 255));
        lcdNumberMinFanSpeed->setValueColor(QColor(48, 224, 77));
        lcdNumberMinFanSpeed->setBarWidth(10);
        lcdNumberMinFanSpeed->setProperty("showtext", QVariant(true));
        lcdNumberMinFanSpeed->setProperty("infinity", QVariant(false));

        horizontalLayout_11->addWidget(lcdNumberMinFanSpeed);


        gridLayout_4->addWidget(groupBox_10, 1, 2, 1, 1);

        groupBox_11 = new QGroupBox(tab);
        groupBox_11->setObjectName(QString::fromUtf8("groupBox_11"));
        groupBox_11->setMinimumSize(QSize(0, 58));
        groupBox_11->setStyleSheet(QString::fromUtf8(""));
        groupBox_11->setFlat(false);
        horizontalLayout_12 = new QHBoxLayout(groupBox_11);
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(-1, 0, -1, 0);
        label_16 = new QLabel(groupBox_11);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        horizontalLayout_12->addWidget(label_16);

        lcdNumberMaxGPUClock = new CircularProgress(groupBox_11);
        lcdNumberMaxGPUClock->setObjectName(QString::fromUtf8("lcdNumberMaxGPUClock"));
        lcdNumberMaxGPUClock->setMinimumSize(QSize(50, 50));
        lcdNumberMaxGPUClock->setMaximumSize(QSize(50, 50));
        lcdNumberMaxGPUClock->setMax(100);
        lcdNumberMaxGPUClock->setValue(0);
        lcdNumberMaxGPUClock->setBgColor(QColor(255, 255, 255));
        lcdNumberMaxGPUClock->setValueColor(QColor(48, 224, 77));
        lcdNumberMaxGPUClock->setBarWidth(10);
        lcdNumberMaxGPUClock->setProperty("showtext", QVariant(true));
        lcdNumberMaxGPUClock->setProperty("infinity", QVariant(false));

        horizontalLayout_12->addWidget(lcdNumberMaxGPUClock);


        gridLayout_4->addWidget(groupBox_11, 0, 3, 1, 1);

        groupBox_12 = new QGroupBox(tab);
        groupBox_12->setObjectName(QString::fromUtf8("groupBox_12"));
        groupBox_12->setMinimumSize(QSize(0, 58));
        groupBox_12->setStyleSheet(QString::fromUtf8(""));
        groupBox_12->setFlat(false);
        horizontalLayout_13 = new QHBoxLayout(groupBox_12);
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        horizontalLayout_13->setContentsMargins(-1, 0, -1, 0);
        label_17 = new QLabel(groupBox_12);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        horizontalLayout_13->addWidget(label_17);

        lcdNumberMinGPUClock = new CircularProgress(groupBox_12);
        lcdNumberMinGPUClock->setObjectName(QString::fromUtf8("lcdNumberMinGPUClock"));
        lcdNumberMinGPUClock->setMinimumSize(QSize(50, 50));
        lcdNumberMinGPUClock->setMaximumSize(QSize(50, 50));
        lcdNumberMinGPUClock->setMax(100);
        lcdNumberMinGPUClock->setValue(0);
        lcdNumberMinGPUClock->setBgColor(QColor(255, 255, 255));
        lcdNumberMinGPUClock->setValueColor(QColor(48, 224, 77));
        lcdNumberMinGPUClock->setBarWidth(10);
        lcdNumberMinGPUClock->setProperty("showtext", QVariant(true));
        lcdNumberMinGPUClock->setProperty("infinity", QVariant(false));

        horizontalLayout_13->addWidget(lcdNumberMinGPUClock);


        gridLayout_4->addWidget(groupBox_12, 1, 3, 1, 1);

        groupBox_13 = new QGroupBox(tab);
        groupBox_13->setObjectName(QString::fromUtf8("groupBox_13"));
        groupBox_13->setMinimumSize(QSize(0, 58));
        groupBox_13->setStyleSheet(QString::fromUtf8(""));
        groupBox_13->setFlat(false);
        horizontalLayout_14 = new QHBoxLayout(groupBox_13);
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(-1, 0, -1, 0);
        label_10 = new QLabel(groupBox_13);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_14->addWidget(label_10);

        lcdNumberMaxMemClock = new CircularProgress(groupBox_13);
        lcdNumberMaxMemClock->setObjectName(QString::fromUtf8("lcdNumberMaxMemClock"));
        lcdNumberMaxMemClock->setMinimumSize(QSize(50, 50));
        lcdNumberMaxMemClock->setMaximumSize(QSize(50, 50));
        lcdNumberMaxMemClock->setMax(100);
        lcdNumberMaxMemClock->setValue(0);
        lcdNumberMaxMemClock->setBgColor(QColor(255, 255, 255));
        lcdNumberMaxMemClock->setValueColor(QColor(48, 224, 77));
        lcdNumberMaxMemClock->setBarWidth(10);
        lcdNumberMaxMemClock->setProperty("showtext", QVariant(true));
        lcdNumberMaxMemClock->setProperty("infinity", QVariant(false));

        horizontalLayout_14->addWidget(lcdNumberMaxMemClock);


        gridLayout_4->addWidget(groupBox_13, 0, 4, 1, 1);

        groupBox_14 = new QGroupBox(tab);
        groupBox_14->setObjectName(QString::fromUtf8("groupBox_14"));
        groupBox_14->setMinimumSize(QSize(0, 58));
        groupBox_14->setStyleSheet(QString::fromUtf8(""));
        groupBox_14->setFlat(false);
        horizontalLayout_15 = new QHBoxLayout(groupBox_14);
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        horizontalLayout_15->setContentsMargins(-1, 0, -1, 0);
        label_12 = new QLabel(groupBox_14);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        horizontalLayout_15->addWidget(label_12);

        lcdNumberMinMemClock = new CircularProgress(groupBox_14);
        lcdNumberMinMemClock->setObjectName(QString::fromUtf8("lcdNumberMinMemClock"));
        lcdNumberMinMemClock->setMinimumSize(QSize(50, 50));
        lcdNumberMinMemClock->setMaximumSize(QSize(50, 50));
        lcdNumberMinMemClock->setMax(100);
        lcdNumberMinMemClock->setValue(0);
        lcdNumberMinMemClock->setBgColor(QColor(255, 255, 255));
        lcdNumberMinMemClock->setValueColor(QColor(48, 224, 77));
        lcdNumberMinMemClock->setBarWidth(10);
        lcdNumberMinMemClock->setProperty("showtext", QVariant(true));
        lcdNumberMinMemClock->setProperty("infinity", QVariant(false));

        horizontalLayout_15->addWidget(lcdNumberMinMemClock);


        gridLayout_4->addWidget(groupBox_14, 1, 4, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        tab_2->setStyleSheet(QString::fromUtf8("QGroupBox{\n"
"	background-color: #262728;\n"
"	border-radius: 4px;\n"
"	border-color: #262728;\n"
"	color: #ffffff;\n"
" 	margin : 0px;\n"
"	padding: 0 0 0 0;\n"
" 	margin-top: 0px;\n"
"	margin-bottom: 0px;\n"
"	min-height: 58px;\n"
"\n"
"}\n"
"\n"
"QLabel{\n"
"color: #ffffff;\n"
"}\n"
"\n"
""));
        gridLayout_3 = new QGridLayout(tab_2);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        groupBox_18 = new QGroupBox(tab_2);
        groupBox_18->setObjectName(QString::fromUtf8("groupBox_18"));
        horizontalLayout_19 = new QHBoxLayout(groupBox_18);
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_19->setObjectName(QString::fromUtf8("horizontalLayout_19"));
        horizontalLayout_19->setContentsMargins(-1, 0, -1, 0);
        label_25 = new QLabel(groupBox_18);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        horizontalLayout_19->addWidget(label_25);

        lcdNumber_AMD_MinTemp = new CircularProgress(groupBox_18);
        lcdNumber_AMD_MinTemp->setObjectName(QString::fromUtf8("lcdNumber_AMD_MinTemp"));
        lcdNumber_AMD_MinTemp->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MinTemp->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MinTemp->setValue(0);
        lcdNumber_AMD_MinTemp->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MinTemp->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MinTemp->setBarWidth(10);

        horizontalLayout_19->addWidget(lcdNumber_AMD_MinTemp);


        gridLayout_3->addWidget(groupBox_18, 1, 1, 1, 1);

        groupBox_17 = new QGroupBox(tab_2);
        groupBox_17->setObjectName(QString::fromUtf8("groupBox_17"));
        horizontalLayout_18 = new QHBoxLayout(groupBox_17);
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_18->setObjectName(QString::fromUtf8("horizontalLayout_18"));
        horizontalLayout_18->setContentsMargins(-1, 0, -1, 0);
        label_24 = new QLabel(groupBox_17);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        horizontalLayout_18->addWidget(label_24);

        lcdNumber_AMD_MaxTemp = new CircularProgress(groupBox_17);
        lcdNumber_AMD_MaxTemp->setObjectName(QString::fromUtf8("lcdNumber_AMD_MaxTemp"));
        lcdNumber_AMD_MaxTemp->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MaxTemp->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MaxTemp->setValue(0);
        lcdNumber_AMD_MaxTemp->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MaxTemp->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MaxTemp->setBarWidth(10);

        horizontalLayout_18->addWidget(lcdNumber_AMD_MaxTemp);


        gridLayout_3->addWidget(groupBox_17, 0, 1, 1, 1);

        groupBox_16 = new QGroupBox(tab_2);
        groupBox_16->setObjectName(QString::fromUtf8("groupBox_16"));
        horizontalLayout_17 = new QHBoxLayout(groupBox_16);
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        horizontalLayout_17->setContentsMargins(-1, 0, -1, 0);
        label_33 = new QLabel(groupBox_16);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        horizontalLayout_17->addWidget(label_33);

        lcdNumber_AMD_MinPoxer = new CircularProgress(groupBox_16);
        lcdNumber_AMD_MinPoxer->setObjectName(QString::fromUtf8("lcdNumber_AMD_MinPoxer"));
        lcdNumber_AMD_MinPoxer->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MinPoxer->setValue(0);
        lcdNumber_AMD_MinPoxer->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MinPoxer->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MinPoxer->setBarWidth(10);

        horizontalLayout_17->addWidget(lcdNumber_AMD_MinPoxer);


        gridLayout_3->addWidget(groupBox_16, 1, 0, 1, 1);

        groupBox_15 = new QGroupBox(tab_2);
        groupBox_15->setObjectName(QString::fromUtf8("groupBox_15"));
        horizontalLayout_16 = new QHBoxLayout(groupBox_15);
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        horizontalLayout_16->setContentsMargins(-1, 0, -1, 0);
        label_32 = new QLabel(groupBox_15);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        horizontalLayout_16->addWidget(label_32);

        lcdNumber_AMD_MaxPower = new CircularProgress(groupBox_15);
        lcdNumber_AMD_MaxPower->setObjectName(QString::fromUtf8("lcdNumber_AMD_MaxPower"));
        lcdNumber_AMD_MaxPower->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MaxPower->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MaxPower->setValue(0);
        lcdNumber_AMD_MaxPower->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MaxPower->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MaxPower->setBarWidth(10);

        horizontalLayout_16->addWidget(lcdNumber_AMD_MaxPower);


        gridLayout_3->addWidget(groupBox_15, 0, 0, 1, 1);

        groupBox_33 = new QGroupBox(tab_2);
        groupBox_33->setObjectName(QString::fromUtf8("groupBox_33"));
        horizontalLayout_35 = new QHBoxLayout(groupBox_33);
        horizontalLayout_35->setSpacing(6);
        horizontalLayout_35->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_35->setObjectName(QString::fromUtf8("horizontalLayout_35"));
        horizontalLayout_35->setContentsMargins(-1, 0, -1, 0);
        label_27 = new QLabel(groupBox_33);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        horizontalLayout_35->addWidget(label_27);

        lcdNumber_AMD_MaxFan = new CircularProgress(groupBox_33);
        lcdNumber_AMD_MaxFan->setObjectName(QString::fromUtf8("lcdNumber_AMD_MaxFan"));
        lcdNumber_AMD_MaxFan->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MaxFan->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MaxFan->setValue(0);
        lcdNumber_AMD_MaxFan->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MaxFan->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MaxFan->setBarWidth(10);

        horizontalLayout_35->addWidget(lcdNumber_AMD_MaxFan);


        gridLayout_3->addWidget(groupBox_33, 0, 2, 1, 1);

        groupBox_34 = new QGroupBox(tab_2);
        groupBox_34->setObjectName(QString::fromUtf8("groupBox_34"));
        horizontalLayout_36 = new QHBoxLayout(groupBox_34);
        horizontalLayout_36->setSpacing(6);
        horizontalLayout_36->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_36->setObjectName(QString::fromUtf8("horizontalLayout_36"));
        horizontalLayout_36->setContentsMargins(-1, 0, -1, 0);
        label_26 = new QLabel(groupBox_34);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        horizontalLayout_36->addWidget(label_26);

        lcdNumber_AMD_MinFan = new CircularProgress(groupBox_34);
        lcdNumber_AMD_MinFan->setObjectName(QString::fromUtf8("lcdNumber_AMD_MinFan"));
        lcdNumber_AMD_MinFan->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MinFan->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MinFan->setValue(0);
        lcdNumber_AMD_MinFan->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MinFan->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MinFan->setBarWidth(10);

        horizontalLayout_36->addWidget(lcdNumber_AMD_MinFan);


        gridLayout_3->addWidget(groupBox_34, 1, 2, 1, 1);

        groupBox_35 = new QGroupBox(tab_2);
        groupBox_35->setObjectName(QString::fromUtf8("groupBox_35"));
        horizontalLayout_37 = new QHBoxLayout(groupBox_35);
        horizontalLayout_37->setSpacing(6);
        horizontalLayout_37->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_37->setObjectName(QString::fromUtf8("horizontalLayout_37"));
        horizontalLayout_37->setContentsMargins(-1, 0, -1, 0);
        label_28 = new QLabel(groupBox_35);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        horizontalLayout_37->addWidget(label_28);

        lcdNumber_AMD_MaxClock = new CircularProgress(groupBox_35);
        lcdNumber_AMD_MaxClock->setObjectName(QString::fromUtf8("lcdNumber_AMD_MaxClock"));
        lcdNumber_AMD_MaxClock->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MaxClock->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MaxClock->setValue(0);
        lcdNumber_AMD_MaxClock->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MaxClock->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MaxClock->setBarWidth(10);

        horizontalLayout_37->addWidget(lcdNumber_AMD_MaxClock);


        gridLayout_3->addWidget(groupBox_35, 0, 3, 1, 1);

        groupBox_36 = new QGroupBox(tab_2);
        groupBox_36->setObjectName(QString::fromUtf8("groupBox_36"));
        horizontalLayout_38 = new QHBoxLayout(groupBox_36);
        horizontalLayout_38->setSpacing(6);
        horizontalLayout_38->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_38->setObjectName(QString::fromUtf8("horizontalLayout_38"));
        horizontalLayout_38->setContentsMargins(-1, 0, -1, 0);
        label_29 = new QLabel(groupBox_36);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        horizontalLayout_38->addWidget(label_29);

        lcdNumber_AMD_MinClock = new CircularProgress(groupBox_36);
        lcdNumber_AMD_MinClock->setObjectName(QString::fromUtf8("lcdNumber_AMD_MinClock"));
        lcdNumber_AMD_MinClock->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MinClock->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MinClock->setValue(0);
        lcdNumber_AMD_MinClock->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MinClock->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MinClock->setBarWidth(10);

        horizontalLayout_38->addWidget(lcdNumber_AMD_MinClock);


        gridLayout_3->addWidget(groupBox_36, 1, 3, 1, 1);

        groupBox_37 = new QGroupBox(tab_2);
        groupBox_37->setObjectName(QString::fromUtf8("groupBox_37"));
        horizontalLayout_39 = new QHBoxLayout(groupBox_37);
        horizontalLayout_39->setSpacing(6);
        horizontalLayout_39->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_39->setObjectName(QString::fromUtf8("horizontalLayout_39"));
        horizontalLayout_39->setContentsMargins(-1, 0, -1, 0);
        label_30 = new QLabel(groupBox_37);
        label_30->setObjectName(QString::fromUtf8("label_30"));

        horizontalLayout_39->addWidget(label_30);

        lcdNumber_AMD_MaxMemClock = new CircularProgress(groupBox_37);
        lcdNumber_AMD_MaxMemClock->setObjectName(QString::fromUtf8("lcdNumber_AMD_MaxMemClock"));
        lcdNumber_AMD_MaxMemClock->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MaxMemClock->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MaxMemClock->setValue(0);
        lcdNumber_AMD_MaxMemClock->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MaxMemClock->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MaxMemClock->setBarWidth(10);

        horizontalLayout_39->addWidget(lcdNumber_AMD_MaxMemClock);


        gridLayout_3->addWidget(groupBox_37, 0, 4, 1, 1);

        groupBox_38 = new QGroupBox(tab_2);
        groupBox_38->setObjectName(QString::fromUtf8("groupBox_38"));
        horizontalLayout_40 = new QHBoxLayout(groupBox_38);
        horizontalLayout_40->setSpacing(6);
        horizontalLayout_40->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_40->setObjectName(QString::fromUtf8("horizontalLayout_40"));
        horizontalLayout_40->setContentsMargins(-1, 0, -1, 0);
        label_31 = new QLabel(groupBox_38);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        horizontalLayout_40->addWidget(label_31);

        lcdNumber_AMD_MinMemClock = new CircularProgress(groupBox_38);
        lcdNumber_AMD_MinMemClock->setObjectName(QString::fromUtf8("lcdNumber_AMD_MinMemClock"));
        lcdNumber_AMD_MinMemClock->setMinimumSize(QSize(50, 50));
        lcdNumber_AMD_MinMemClock->setMaximumSize(QSize(50, 50));
        lcdNumber_AMD_MinMemClock->setValue(0);
        lcdNumber_AMD_MinMemClock->setBgColor(QColor(255, 255, 255));
        lcdNumber_AMD_MinMemClock->setValueColor(QColor(48, 224, 77));
        lcdNumber_AMD_MinMemClock->setBarWidth(10);

        horizontalLayout_40->addWidget(lcdNumber_AMD_MinMemClock);


        gridLayout_3->addWidget(groupBox_38, 1, 4, 1, 1);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        horizontalLayout = new QHBoxLayout(tab_3);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        groupBoxWatchdog = new QGroupBox(tab_3);
        groupBoxWatchdog->setObjectName(QString::fromUtf8("groupBoxWatchdog"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(groupBoxWatchdog->sizePolicy().hasHeightForWidth());
        groupBoxWatchdog->setSizePolicy(sizePolicy2);
        groupBoxWatchdog->setStyleSheet(QString::fromUtf8("QGroupBox\n"
" {\n"
"    border: 0px solid #e05b5b;\n"
"    border-radius: 0px;\n"
"    margin-top: 1ex; /* leave space at the top for the title */\n"
"}\n"
"\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    subcontrol-position: top left; /* position at the top center */\n"
"    padding: 0 4px;\n"
"}\n"
""));
        groupBoxWatchdog->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        groupBoxWatchdog->setCheckable(true);
        groupBoxWatchdog->setChecked(false);
        gridLayout = new QGridLayout(groupBoxWatchdog);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        spinBoxMax0MHs = new QSpinBox(groupBoxWatchdog);
        spinBoxMax0MHs->setObjectName(QString::fromUtf8("spinBoxMax0MHs"));
        spinBoxMax0MHs->setStyleSheet(QString::fromUtf8(""));
        spinBoxMax0MHs->setMinimum(1);

        gridLayout->addWidget(spinBoxMax0MHs, 0, 1, 2, 1);

        label_3 = new QLabel(groupBoxWatchdog);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 1, 4, 1, 1);

        spinBoxDelay0MHs = new QSpinBox(groupBoxWatchdog);
        spinBoxDelay0MHs->setObjectName(QString::fromUtf8("spinBoxDelay0MHs"));
        spinBoxDelay0MHs->setMinimum(1);
        spinBoxDelay0MHs->setMaximum(600);
        spinBoxDelay0MHs->setValue(20);

        gridLayout->addWidget(spinBoxDelay0MHs, 1, 5, 1, 1);

        spinBoxDelay = new QSpinBox(groupBoxWatchdog);
        spinBoxDelay->setObjectName(QString::fromUtf8("spinBoxDelay"));
        spinBoxDelay->setMinimum(1);

        gridLayout->addWidget(spinBoxDelay, 1, 3, 1, 1);

        label_4 = new QLabel(groupBoxWatchdog);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 1, 0, 1, 1);

        label_7 = new QLabel(groupBoxWatchdog);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 1, 6, 1, 1);

        label_5 = new QLabel(groupBoxWatchdog);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 1, 2, 1, 1);

        spinBoxDelayNoHash = new QSpinBox(groupBoxWatchdog);
        spinBoxDelayNoHash->setObjectName(QString::fromUtf8("spinBoxDelayNoHash"));
        spinBoxDelayNoHash->setMinimum(30);
        spinBoxDelayNoHash->setMaximum(600);
        spinBoxDelayNoHash->setValue(60);

        gridLayout->addWidget(spinBoxDelayNoHash, 1, 7, 1, 1);


        horizontalLayout->addWidget(groupBoxWatchdog);

        tabWidget->addTab(tab_3, QString());

        formLayout->setWidget(2, QFormLayout::SpanningRole, tabWidget);


        formLayout_2->setLayout(0, QFormLayout::FieldRole, formLayout);

        MainWindow->setCentralWidget(centralWidget);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "HashFighter", nullptr));
        pushButton->setText(QString());
        groupBox->setTitle(QString());
        label_34->setText(QApplication::translate("MainWindow", "openssl", nullptr));
        useSSL->setItemText(0, QApplication::translate("MainWindow", "yes", nullptr));
        useSSL->setItemText(1, QApplication::translate("MainWindow", "no", nullptr));

        label_36->setText(QApplication::translate("MainWindow", "waller adress", nullptr));
        label_37->setText(QApplication::translate("MainWindow", "worker name", nullptr));
        label_35->setText(QApplication::translate("MainWindow", "pool : port ", nullptr));
        label_38->setText(QApplication::translate("MainWindow", "mail", nullptr));
        groupBox_3->setTitle(QString());
        label_15->setText(QApplication::translate("MainWindow", "Min power draw:", nullptr));
        groupBox_2->setTitle(QString());
        label_14->setText(QApplication::translate("MainWindow", "Max power draw:", nullptr));
        groupBox_4->setTitle(QString());
        label_6->setText(QApplication::translate("MainWindow", "Max temp:", nullptr));
        groupBox_8->setTitle(QString());
        label_13->setText(QApplication::translate("MainWindow", "Min temp:", nullptr));
        groupBox_9->setTitle(QString());
        label_9->setText(QApplication::translate("MainWindow", "Max fan:", nullptr));
        groupBox_10->setTitle(QString());
        label_11->setText(QApplication::translate("MainWindow", "Min fan:", nullptr));
        groupBox_11->setTitle(QString());
        label_16->setText(QApplication::translate("MainWindow", "Max clock:", nullptr));
        groupBox_12->setTitle(QString());
        label_17->setText(QApplication::translate("MainWindow", "Min clock:", nullptr));
        groupBox_13->setTitle(QString());
        label_10->setText(QApplication::translate("MainWindow", "Max mem clock:", nullptr));
        groupBox_14->setTitle(QString());
        label_12->setText(QApplication::translate("MainWindow", "Min mem clock:", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "NVIDIA", nullptr));
        groupBox_18->setTitle(QString());
        label_25->setText(QApplication::translate("MainWindow", "Min temp:", nullptr));
        groupBox_17->setTitle(QString());
        label_24->setText(QApplication::translate("MainWindow", "Max temp:", nullptr));
        groupBox_16->setTitle(QString());
        label_33->setText(QApplication::translate("MainWindow", "Min power draw:", nullptr));
        groupBox_15->setTitle(QString());
        label_32->setText(QApplication::translate("MainWindow", "Max power draw:", nullptr));
        groupBox_33->setTitle(QString());
        label_27->setText(QApplication::translate("MainWindow", "Max fan:", nullptr));
        groupBox_34->setTitle(QString());
        label_26->setText(QApplication::translate("MainWindow", "Min fan:", nullptr));
        groupBox_35->setTitle(QString());
        label_28->setText(QApplication::translate("MainWindow", "Max clock:", nullptr));
        groupBox_36->setTitle(QString());
        label_29->setText(QApplication::translate("MainWindow", "Min clock:", nullptr));
        groupBox_37->setTitle(QString());
        label_30->setText(QApplication::translate("MainWindow", "Max mem clock:", nullptr));
        groupBox_38->setTitle(QString());
        label_31->setText(QApplication::translate("MainWindow", "Min mem clock:", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "AMD", nullptr));
        groupBoxWatchdog->setTitle(QApplication::translate("MainWindow", "Autorestart", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Delay before monitoring for 0MH/s:", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Max consecutive 0MH/s:", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "Delay before no hash:", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Delay before restart:", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "OPTIONS", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

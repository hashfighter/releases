/********************************************************************************
** Form generated from reading UI file 'helpdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HELPDIALOG_H
#define UI_HELPDIALOG_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_helpDialog
{
public:
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *plainTextEdit;
    QPushButton *pushButtonFinish;

    void setupUi(QDialog *helpDialog)
    {
        if (helpDialog->objectName().isEmpty())
            helpDialog->setObjectName(QString::fromUtf8("helpDialog"));
        helpDialog->resize(500, 217);
        helpDialog->setLayoutDirection(Qt::LeftToRight);
        helpDialog->setStyleSheet(QString::fromUtf8("QDialog{\n"
"background-color: #11192C;\n"
"min-width: 500px;\n"
"}"));
        verticalLayout = new QVBoxLayout(helpDialog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        plainTextEdit = new QPlainTextEdit(helpDialog);
        plainTextEdit->setObjectName(QString::fromUtf8("plainTextEdit"));
        plainTextEdit->setStyleSheet(QString::fromUtf8("QPlainTextEdit{\n"
"	font: 12pt \"MS Shell Dlg 2\";\n"
"	color: #CFD0D2;\n"
"    background-color: transparent;\n"
"}"));
        plainTextEdit->setFrameShape(QFrame::NoFrame);
        plainTextEdit->setLineWidth(0);
        plainTextEdit->setLineWrapMode(QPlainTextEdit::WidgetWidth);
        plainTextEdit->setReadOnly(true);
        plainTextEdit->setBackgroundVisible(false);

        verticalLayout->addWidget(plainTextEdit);

        pushButtonFinish = new QPushButton(helpDialog);
        pushButtonFinish->setObjectName(QString::fromUtf8("pushButtonFinish"));
        pushButtonFinish->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButtonFinish->sizePolicy().hasHeightForWidth());
        pushButtonFinish->setSizePolicy(sizePolicy);
        pushButtonFinish->setMinimumSize(QSize(100, 30));
        pushButtonFinish->setMaximumSize(QSize(100, 30));
        pushButtonFinish->setLayoutDirection(Qt::LeftToRight);
        pushButtonFinish->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border-radius: 15px;\n"
"	font: 85 10pt \"Arial\";\n"
"    background-color: #71C8F3;\n"
"	min-width:  100px;\n"
"	min-height:  30px;\n"
"    max-width:  100px;\n"
"	max-height:  30px;\n"
"    padding:  0;\n"
"    margin: 0;\n"
"	qproperty-alignment: 'AlignHCenter';\n"
"}\n"
"QPushButton:hover{\n"
"    background-color: #3D8ED6;\n"
"}\n"
"QPushButton:hover:pressed{\n"
"    background-color: #2F5BAC;\n"
"}\n"
""));
        pushButtonFinish->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        pushButtonFinish->setFlat(true);

        verticalLayout->addWidget(pushButtonFinish, 0, Qt::AlignHCenter);


        retranslateUi(helpDialog);

        QMetaObject::connectSlotsByName(helpDialog);
    } // setupUi

    void retranslateUi(QDialog *helpDialog)
    {
        helpDialog->setWindowTitle(QApplication::translate("helpDialog", "Help", nullptr));
#ifndef QT_NO_WHATSTHIS
        helpDialog->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        plainTextEdit->setPlainText(QApplication::translate("helpDialog", "Selectum is a GUI miners manager with abilities to run multiple algorythms and cryptocurrencies mining with lot of usefull features like: watchdog for restarting miner, autostart, enhanced displaying of miner output - highlighted successful solutions, shares & zero hashrate, display  information for nVidia cards , power drawing - a minimum and a maximum from all cards, integrated overclocking of nVidia cards, integrated pools monitoring, etc.", nullptr));
        pushButtonFinish->setText(QApplication::translate("helpDialog", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class helpDialog: public Ui_helpDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HELPDIALOG_H
